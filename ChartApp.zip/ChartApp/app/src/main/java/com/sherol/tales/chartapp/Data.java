package com.sherol.tales.chartapp;

/**
 * Created by tales on 25/10/2015.
 */
public class Data {
    float val1;
    float val2;
    float val3;
    float val4;
    float val5;
}
